// +build windows

package creds

var netrcBasename = "_netrc"
