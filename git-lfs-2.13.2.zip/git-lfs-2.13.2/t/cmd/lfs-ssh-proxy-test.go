// +build testtools

package main

import "fmt"

func main() {
	fmt.Println("SSH PROXY TEST called")
}
